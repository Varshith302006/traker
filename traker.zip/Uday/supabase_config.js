// supabase_config.example.js
// Rename to supabase_config.js and fill with your Supabase project info
// Do NOT commit your real anon key to public repos.
window.SUPABASE_URL = "https://jdfbscthdbbcctlyhhjp.supabase.co";
window.SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpkZmJzY3RoZGJiY2N0bHloaGpwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ5MjkxMTcsImV4cCI6MjA3MDUwNTExN30.pGUGmxNuShPeO04yvPZyhF0f9wThrGgGhCaw0gZoqcM";
