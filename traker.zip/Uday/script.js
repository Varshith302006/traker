// script.js - Supabase-powered Consistency Tracker
// Requires: supabase_config.js exposing window.SUPABASE_URL & window.SUPABASE_ANON_KEY

if (!window.SUPABASE_URL || !window.SUPABASE_ANON_KEY) {
  alert("Please configure supabase_config.js with SUPABASE_URL and SUPABASE_ANON_KEY");
}

const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);

// ---------- DOM refs ----------
const qs = s => document.querySelector(s);
const qsa = s => Array.from(document.querySelectorAll(s));

const authEmail = qs("#auth-email");
const authPass = qs("#auth-pass");
const btnSignup = qs("#btn-signup");
const btnSignin = qs("#btn-signin");
const btnSignout = qs("#btn-signout");
const authControls = qs("#auth-controls");
const userBox = qs("#user-box");
const userEmailSpan = qs("#user-email");

const taskInput = qs("#taskInput");
const addTaskBtn = qs("#addTaskBtn");
const taskList = qs("#taskList");

const drawer = qs("#drawer");
const drawerDate = qs("#drawerDate");
const drawerTaskList = qs("#drawerTaskList");
const drawerTaskInput = qs("#drawerTaskInput");
const drawerAddTaskBtn = qs("#drawerAddTaskBtn");
const drawerPct = qs("#drawerPct");
const drawerFill = qs("#drawerFill");
const closeDrawer = qs("#closeDrawer");

const dayGrid = qs("#dayGrid");
const todayLabel = qs("#todayLabel");
const todayPct = qs("#todayPct");
const mainProgressFill = qs("#mainProgressFill");
const mainProgressText = qs("#mainProgressText");
const dashboardStreakEl = qs("#dashboardStreak");

const refreshBtn = qs("#refreshBtn");
const resetLocalBtn = qs("#resetLocal");
const settingsBtn = qs("#settingsBtn");
const settingsModal = qs("#settingsModal");
const closeSettings = qs("#closeSettings");
const saveSettings = qs("#saveSettings");
const thresholdInput = qs("#thresholdInput");
const themeSelect = qs("#themeSelect");

const celebrate = qs("#celebrate");

// ---------- State ----------
let tasksCache = []; // { id, title, completed, date }  (date = 'YYYY-MM-DD')
let currentUser = null;
let currentDate = todayISO();
const LS_TASKS_KEY = "consistency_tasks_v1";
const DEFAULT_THRESHOLD = 80;

// ---------- Helpers ----------
function todayISO(d = new Date()) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function saveTasksToLocal() {
  try { localStorage.setItem(LS_TASKS_KEY, JSON.stringify(tasksCache)); } catch(e) {}
}
function loadTasksFromLocal() {
  try {
    const raw = localStorage.getItem(LS_TASKS_KEY);
    if (raw) tasksCache = JSON.parse(raw);
  } catch(e){}
}

// ---------- Auth ----------
btnSignup.addEventListener("click", async () => {
  const email = authEmail.value.trim();
  const pass = authPass.value;
  if (!email || !pass) return alert("Enter email and password");
  const { error } = await supabase.auth.signUp({ email, password: pass });
  if (error) return alert("Sign up failed: " + error.message);
  alert("Signed up. Check email if confirmation is enabled.");
});

btnSignin.addEventListener("click", async () => {
  const email = authEmail.value.trim();
  const pass = authPass.value;
  if (!email || !pass) return alert("Enter email and password");
  const { error } = await supabase.auth.signInWithPassword({ email, password: pass });
  if (error) return alert("Sign in failed: " + error.message);
  // onAuthStateChange will handle UI
});

btnSignout.addEventListener("click", async () => {
  await supabase.auth.signOut();
});

// listen for auth changes
supabase.auth.onAuthStateChange((event, session) => {
  currentUser = session?.user ?? null;
  updateAuthUI();
  if (currentUser) loadAllForUser();
  else {
    tasksCache = [];
    renderMainToday();
    buildGrid();
  }
});

async function updateAuthUI(){
  if (currentUser) {
    authControls.style.display = "none";
    userBox.style.display = "flex";
    userEmailSpan.textContent = currentUser.email;
    qs(".left-panel").style.opacity = 1;
    qs(".right-panel").style.opacity = 1;
  } else {
    authControls.style.display = "flex";
    userBox.style.display = "none";
    userEmailSpan.textContent = "";
    qs(".left-panel").style.opacity = 0.6;
    qs(".right-panel").style.opacity = 0.6;
  }
}

// ---------- Supabase CRUD ----------
async function fetchTasksFromServer() {
  if (!currentUser) return [];
  const { data, error } = await supabase
    .from("tasks")
    .select("id, title, date, completed, created_at")
    .eq("user_id", currentUser.id)
    .order("date", { ascending: false })
    .order("created_at", { ascending: false });

  if (error) {
    console.warn("fetch tasks error", error);
    return [];
  }
  return data.map(d => ({
    id: d.id,
    title: d.title,
    completed: !!d.completed,
    date: d.date // should be ISO 'YYYY-MM-DD'
  }));
}

async function createTaskOnServer(title, date) {
  if (!currentUser) {
    console.warn("No current user when creating task");
    return null;
  }
  const { data, error } = await supabase
    .from("tasks")
    .insert([{ title, date, user_id: currentUser.id }])  // pass date & user_id
    .select()
    .single();

  if (error) {
    console.error("create error", error.message, error.details, error.hint);
    return null;
  }
  return data;
}

async function updateTaskOnServer(id, patch) {
  if (!currentUser) return null;
  const { data, error } = await supabase
    .from("tasks")
    .update(patch)
    .eq("id", id)
    .select()
    .single();
  if (error) { console.warn("update err", error); return null; }
  return {
    id: data.id, title: data.title, completed: !!data.completed, date: data.date
  };
}

async function deleteTaskOnServer(id) {
  if (!currentUser) return false;
  const { error } = await supabase.from("tasks").delete().eq("id", id);
  if (error) { console.warn("delete err", error); return false; }
  return true;
}

// ---------- UI rendering & logic ----------
function computePctFor(date) {
  const items = tasksCache.filter(t => t.date === date);
  if (items.length === 0) return 0;
  const done = items.filter(t => t.completed).length;
  return Math.round((done / items.length) * 100);
}

function renderDrawerProgress(date) {
  const pct = computePctFor(date);
  drawerPct.textContent = pct + "%";
  drawerFill.style.width = pct + "%";
}

function renderTasks(tasks) {
  // Fixed: tasksUl was undefined, assuming drawerTaskList is the ul container for drawer tasks
  drawerTaskList.innerHTML = '';
  tasks.forEach(t => {
    const li = document.createElement('li');

    // Only show title
    li.textContent = t.title + ' ';

    const del = document.createElement('button');
    del.textContent = 'Delete';
    del.addEventListener('click', () => deleteTask(t.id));

    li.appendChild(del);
    drawerTaskList.appendChild(li);
  });
}

function renderMainToday(){
  const today = todayISO();
  const todayTasks = tasksCache.filter(t => t.date === today);
  taskList.innerHTML = "";
  if (todayTasks.length === 0) {
    taskList.innerHTML = `<li class="muted">No tasks for today. Add one!</li>`;
  } else {
    todayTasks.forEach(t => {
      const li = document.createElement("li");
      li.className = t.completed ? "done" : "";
      const bullet = document.createElement("div"); bullet.className = "bullet"; bullet.textContent = t.completed ? "✓" : "•";
      li.appendChild(bullet);
      const span = document.createElement("div"); span.style.flex = "1"; span.textContent = t.title; li.appendChild(span);
      const rem = document.createElement("button"); rem.className = "remove"; rem.textContent = "✕";
      rem.addEventListener("click", async (e) => {
        e.stopPropagation();
        const prev = tasksCache.slice();
        tasksCache = tasksCache.filter(x => x.id !== t.id);
        renderMainToday(); refreshDashboardColors();
        const ok = await deleteTaskOnServer(t.id);
        if (!ok) { tasksCache = prev; renderMainToday(); refreshDashboardColors(); alert("Delete failed"); }
        else saveTasksToLocal();
      });
      li.appendChild(rem);

      li.addEventListener("click", async () => {
        t.completed = !t.completed;
        li.classList.toggle("done", t.completed);
        renderMainToday();
        refreshDashboardColors();
        saveTasksToLocal();
        const updated = await updateTaskOnServer(t.id, { completed: t.completed });
        if (!updated) { t.completed = !t.completed; renderMainToday(); refreshDashboardColors(); alert("Update failed"); }
      });

      taskList.appendChild(li);
    });
  }

  const pctNum = computePctFor(todayISO());
  todayPct.textContent = pctNum + "%";
  mainProgressFill.style.width = pctNum + "%";
  mainProgressText.textContent = pctNum + "%";
  if (pctNum < 40) mainProgressFill.style.background = "linear-gradient(90deg, #ef4444, #fb923c)";
  else if (pctNum < 80) mainProgressFill.style.background = "linear-gradient(90deg, #f59e0b, #facc15)";
  else mainProgressFill.style.background = "linear-gradient(90deg, #34d399, #10b981)";
}

function refreshDashboardColors(){
  const map = {};
  tasksCache.forEach(t => {
    map[t.date] = map[t.date] || { total:0, done:0 };
    map[t.date].total++;
    if (t.completed) map[t.date].done++;
  });
  qsa(".day").forEach(el => {
    const date = el.getAttribute("data-date");
    const stats = map[date];
    el.classList.remove("completed","partial","pending");
    if (!stats) {
      el.classList.add("pending");
    } else {
      const pct = Math.round((stats.done / stats.total) * 100);
      const threshold = Number(thresholdInput?.value || DEFAULT_THRESHOLD);
      if (pct >= threshold) el.classList.add("completed");
      else if (pct > 0) el.classList.add("partial");
      else el.classList.add("pending");
    }
  });
  renderMainToday();
  saveTasksToLocal();
  computeStreak();
}

// Drawer handling
async function openDrawerFor(date) {
  currentDate = date;
  drawer.classList.add("open");
  drawer.setAttribute("aria-hidden", "false");
  drawerDate.textContent = new Date(date).toDateString();

  // Removed fetch from server here, just render from cache:
  renderTaskListForDate(date);
}

closeDrawer.addEventListener("click", () => {
  drawer.classList.remove("open");
  drawer.setAttribute("aria-hidden","true");
});

// Main add task button
addTaskBtn.addEventListener("click", async () => {
  if (!currentUser) return alert("Please sign in to save tasks.");
  const text = taskInput.value.trim();
  if (!text) return;
  const tempId = "tmp-" + Date.now();
  tasksCache.unshift({ id: tempId, title: text, date: todayISO(), completed: false });
  renderMainToday(); 
  refreshDashboardColors();
  taskInput.value = "";
  
  const saved = await createTaskOnServer(text, todayISO()); // pass date here
  if (saved) {
    tasksCache = tasksCache.map(t => t.id === tempId ? saved : t);
    refreshDashboardColors();
    saveTasksToLocal();
  } else {
    alert("Failed to save to server. Task kept locally.");
  }
});

// Drawer add task button
drawerAddTaskBtn.addEventListener("click", async () => {
  if (!currentUser) return alert("Please sign in to save tasks.");
  const text = drawerTaskInput.value.trim();
  if (!text) return;
  const tempId = "tmp-" + Date.now();
  tasksCache.unshift({ id: tempId, title: text, date: currentDate, completed: false });
  renderTaskListForDate(currentDate); 
  refreshDashboardColors();
  drawerTaskInput.value = "";
  
  const saved = await createTaskOnServer(text, currentDate); // pass date here
  if (saved) {
    tasksCache = tasksCache.map(t => t.id === tempId ? saved : t);
    renderTaskListForDate(currentDate);
    refreshDashboardColors();
    saveTasksToLocal();
  } else {
    alert("Failed to save to server. Task kept locally.");
  }
});

// Grid & streak
function formatDayKey(year, month, day){
  const mm = String(month).padStart(2,"0");
  const dd = String(day).padStart(2,"0");
  return `${year}-${mm}-${dd}`;
}
function buildGrid() {
  const today = new Date();
  dayGrid.innerHTML = "";

  // Loop from 29 days ago up to today (total 30 days)
  for (let i = 29; i >= 0; i--) {
    const dateObj = new Date(today);
    dateObj.setDate(today.getDate() - i);

    const dateKey = todayISO(dateObj);

    const el = document.createElement("div");
    el.className = "day";
    el.textContent = dateObj.getDate(); // show day number only
    el.setAttribute("data-date", dateKey);

    // Highlight today
    if (dateKey === todayISO()) el.classList.add("today");

    // (Optional safety) mark future days — though this loop won't have any
    if (dateObj > today) el.classList.add("future");

    // Click opens drawer for that date
    el.addEventListener("click", () => openDrawerFor(dateKey));

    dayGrid.appendChild(el);
  }
}

function renderTaskListForDate(date) {
  drawerTaskList.innerHTML = "";

  const tasksForDate = tasksCache.filter(t => t.date === date);

  if (tasksForDate.length === 0) {
    drawerTaskList.innerHTML = `<li class="muted">No tasks for this day.</li>`;
  } else {
    tasksForDate.forEach(t => {
      const li = document.createElement("li");
      li.className = t.completed ? "done" : "";

      const bullet = document.createElement("div");
      bullet.className = "bullet";
      bullet.textContent = t.completed ? "✓" : "•";
      li.appendChild(bullet);

      const span = document.createElement("div");
      span.style.flex = "1";
      span.textContent = t.title;
      li.appendChild(span);

      const rem = document.createElement("button");
      rem.className = "remove";
      rem.textContent = "✕";
      rem.addEventListener("click", async (e) => {
        e.stopPropagation();
        const prev = tasksCache.slice();
        tasksCache = tasksCache.filter(x => x.id !== t.id);
        renderTaskListForDate(date);
        refreshDashboardColors();
        const ok = await deleteTaskOnServer(t.id);
        if (!ok) {
          tasksCache = prev;
          renderTaskListForDate(date);
          refreshDashboardColors();
          alert("Delete failed");
        } else {
          saveTasksToLocal();
        }
      });
      li.appendChild(rem);

      // Toggle completion
      li.addEventListener("click", async () => {
        t.completed = !t.completed;
        li.classList.toggle("done", t.completed);
        refreshDashboardColors();
        saveTasksToLocal();
        const updated = await updateTaskOnServer(t.id, { completed: t.completed });
        if (!updated) {
          t.completed = !t.completed;
          li.classList.toggle("done", t.completed);
          refreshDashboardColors();
          alert("Update failed");
        }
      });

      drawerTaskList.appendChild(li);
    });
  }

  renderDrawerProgress(date);
}

// compute streak
function computeStreak() {
  const doneEls = qsa(".day.completed");
  const dates = doneEls.map(e => e.getAttribute("data-date")).sort();
  let streak = 0;
  if (!dates.length) { dashboardStreakEl.textContent = `Current streak: 0 days`; return; }
  const doneSet = new Set(dates);
  let cursor = new Date(todayISO());
  if (!doneSet.has(todayISO())) {
    cursor = new Date(dates[dates.length - 1]);
  }
  while (doneSet.has(todayISO(cursor))) {
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }
  dashboardStreakEl.textContent = `Current streak: ${streak} day${streak !== 1 ? "s" : ""}`;
}

// celebration
function pulseCelebrate(){ celebrate.classList.add("show"); setTimeout(()=> celebrate.classList.remove("show"),900); }

// Settings modal
settingsBtn.addEventListener("click", ()=> settingsModal.setAttribute("aria-hidden","false"));
closeSettings.addEventListener("click", ()=> settingsModal.setAttribute("aria-hidden","true"));
saveSettings.addEventListener("click", ()=> {
  localStorage.setItem("consistency_settings", JSON.stringify({ threshold: thresholdInput.value, theme: themeSelect.value }));
  alert("Settings saved");
  settingsModal.setAttribute("aria-hidden","true");
  refreshDashboardColors();
});

// Reset / Refresh
resetLocalBtn.addEventListener("click", ()=> {
  if (!confirm("Clear local UI cache? (Does NOT delete server data)")) return;
  tasksCache = []; saveTasksToLocal(); refreshDashboardColors(); renderMainToday();
});
refreshBtn.addEventListener("click", loadAllForUser);

// initial load & sync
async function loadAllForUser() {
  loadTasksFromLocal();
  buildGrid();
  refreshDashboardColors();
  renderMainToday();

  if (!currentUser) return; // no server sync if not signed in

  // fetch from server and replace local cache
  const serverTasks = await fetchTasksFromServer();
  if (serverTasks && serverTasks.length) {
    tasksCache = serverTasks;
    saveTasksToLocal();
    refreshDashboardColors();
    renderMainToday();
  }
}

// initial setup: load local settings and grid
(function init(){
  todayLabel.textContent = new Date().toDateString();
  const savedSettings = JSON.parse(localStorage.getItem("consistency_settings") || "{}");
  if (savedSettings.threshold) thresholdInput.value = savedSettings.threshold;
  if (savedSettings.theme) document.documentElement.setAttribute("data-theme", savedSettings.theme);
  buildGrid();
  loadTasksFromLocal();
  refreshDashboardColors();
  renderMainToday();
  // check for existing session
  supabase.auth.getSession().then(({ data }) => {
    if (data?.session) {
      currentUser = data.session.user;
      updateAuthUI();
      loadAllForUser();
    }
  });
})();
